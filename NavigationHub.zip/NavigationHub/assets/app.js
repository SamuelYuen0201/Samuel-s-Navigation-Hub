(() => {
  'use strict';
  const CFG = window.NAV_HUB_CONFIG;
  const $ = id => document.getElementById(id);
  const refreshIcons = () => window.lucide?.createIcons();
  const GREETINGS = [
    'Where to, Samuel?', 'What shall we build today, Samuel?',
    'Where does curiosity lead, Samuel?', 'Focus, flow, and create, Samuel.',
    "Systems online. What's next, Samuel?", 'A quiet space for thinking, Samuel.',
    'Ready to explore, Samuel?', 'One step closer to your goals, Samuel.'
  ];
  const COLOR = {
    pink:['bg-pink-500/10','text-pink-600','dark:text-pink-400'],
    red:['bg-red-500/10','text-red-600','dark:text-red-400'],
    zinc:['bg-zinc-500/10','text-zinc-800','dark:text-zinc-200'],
    green:['bg-green-500/10','text-green-600','dark:text-green-400'],
    orange:['bg-orange-500/10','text-orange-600','dark:text-orange-400'],
    amber:['bg-amber-500/10','text-amber-600','dark:text-amber-400'],
    fuchsia:['bg-fuchsia-500/10','text-fuchsia-600','dark:text-fuchsia-400'],
    blue:['bg-blue-500/10','text-blue-600','dark:text-blue-400'],
    teal:['bg-teal-500/10','text-teal-600','dark:text-teal-400'],
    indigo:['bg-indigo-500/10','text-indigo-600','dark:text-indigo-400'],
    violet:['bg-violet-500/10','text-violet-600','dark:text-violet-400'],
    stone:['bg-stone-500/10','text-stone-700','dark:text-stone-300'],
    emerald:['bg-emerald-500/10','text-emerald-600','dark:text-emerald-400'],
    cyan:['bg-cyan-500/10','text-cyan-600','dark:text-cyan-400']
  };
  function el(tag, className='', text=null) {
    const e=document.createElement(tag);
    if (className) e.className=className;
    if (text!==null) e.textContent=text;
    return e;
  }
  function icon(name,className='w-4 h-4') {
    const e=el('i',className);e.dataset.lucide=name;return e;
  }
  function renderNavigation() {
    const root=$('navigationSections');
    CFG.sections.forEach((section,groupIdx)=>{
      const sec=el('section','nav-section');
      const heading=el('div','flex items-center gap-2 mb-4 flex-wrap');
      heading.append(icon(section.icon,'w-4 h-4 text-claude-terracotta'));
      heading.append(el('h3','font-serif text-lg tracking-tight font-medium',`${section.title} · ${section.english}`));
      heading.append(el('span','text-xs text-claude-muted dark:text-claude-darkMuted',section.subtitle));
      const grid=el('div',`grid grid-cols-1 sm:grid-cols-2 ${section.columns} gap-4`);
      section.links.forEach((item,index)=>{
        const color=COLOR[item.color]||COLOR.stone;
        const a=el('a','nav-card liquid-glass animate-card group p-4 rounded-2xl flex flex-col justify-between');
        a.href=item.url;a.target='_blank';a.rel='noopener noreferrer';
        a.style.animationDelay=`${50+groupIdx*190+index*40}ms`;
        const top=el('div');
        const iconRow=el('div','flex items-center justify-between mb-2.5');
        const iconBox=el('div',`w-8 h-8 rounded-xl ${color.join(' ')} flex items-center justify-center`);
        iconBox.append(icon(item.icon));
        iconRow.append(iconBox, icon('arrow-up-right','w-4 h-4 text-claude-muted group-hover:text-claude-terracotta transition-colors'));
        top.append(iconRow,el('h4','font-medium text-sm text-claude-text dark:text-claude-darkText group-hover:text-claude-terracotta transition-colors',item.title),el('p','text-xs text-claude-muted dark:text-claude-darkMuted mt-1 break-all',item.subtitle));
        const foot=el('div','mt-4 pt-2 border-t border-claude-border/40 dark:border-claude-darkBorder/40 flex items-center justify-between gap-2 text-[11px] text-claude-muted');
        foot.append(el('span','',item.footer),el('span',`font-mono text-[10px] ${color.slice(1).join(' ')}`,item.badge));
        a.append(top,foot);grid.append(a);
      });
      sec.append(heading,grid);root.append(sec);
    });
  }
  function renderEngines() {
    const root=$('engineButtons');
    Object.keys(CFG.engines).forEach((name,index)=>{
      const btn=el('button',`engine-badge${index===0?' active':''}`,name);
      btn.type='button';btn.dataset.engine=name;
      btn.addEventListener('click',()=>{
        window.NAV_HUB_ENGINE=name;
        root.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b===btn));
      });
      root.append(btn);
    });
    window.NAV_HUB_ENGINE='Google';
  }
  function filterCards() {
    const q=$('omniInput').value.toLocaleLowerCase().trim();
    $('clearBtn').classList.toggle('hidden',!q);
    document.querySelectorAll('.nav-section').forEach(sec=>{
      let found=0;
      sec.querySelectorAll('.nav-card').forEach(card=>{
        const shown=card.textContent.toLocaleLowerCase().includes(q);
        card.style.display=shown?'flex':'none';
        if(shown) found++;
      });
      sec.classList.toggle('nav-section-empty',found===0);
    });
  }
  function runAiTypewriter() {
    const target=$('typedGreeting');
    const chosen=GREETINGS[Math.floor(Math.random()*GREETINGS.length)];
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {target.textContent=chosen;return;}
    let i=0;
    const handle=setInterval(()=>{target.textContent=chosen.slice(0,++i);if(i>=chosen.length)clearInterval(handle)},40);
  }
  function updateClock() {
    const n=new Date();$('liveClock').textContent=`${String(n.getHours()).padStart(2,'0')}:${String(n.getMinutes()).padStart(2,'0')}`;
  }
  function updateCountdown() {
    const diff=new Date(CFG.examDate).getTime()-Date.now();
    if(diff<=0){$('dseCountdownText').textContent='DSE 中文卷一 開考！';return;}
    const days=Math.floor(diff/86400000),hours=Math.floor(diff%86400000/3600000);
    $('dseCountdownText').textContent=`DSE 中文卷一 · 倒數 ${days} 天 ${hours} 小時`;
  }
  function updateThemeIcon(){ $('themeIcon').dataset.lucide=document.documentElement.classList.contains('dark')?'sun':'moon';refreshIcons(); }
  function initTheme() {
    let saved=null;
    try{saved=localStorage.getItem('claude_hub_theme')}catch{}
    if(saved==='dark'||(!saved&&window.matchMedia('(prefers-color-scheme:dark)').matches))document.documentElement.classList.add('dark');
    updateThemeIcon();
    $('themeToggle').addEventListener('click',()=>{
      const dark=document.documentElement.classList.toggle('dark');
      try{localStorage.setItem('claude_hub_theme',dark?'dark':'light')}catch{}
      updateThemeIcon();
    });
  }
  function bindModals() {
    document.querySelectorAll('[data-open]').forEach(btn=>btn.addEventListener('click',()=>{
      const modal=$(btn.dataset.open);modal.classList.remove('hidden');
      if(btn.dataset.open==='weatherModal')refreshWeatherModal();
    }));
    document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>$(btn.dataset.close).classList.add('hidden')));
    document.querySelectorAll('.modal-shell').forEach(modal=>modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.add('hidden')}));
    document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal-shell').forEach(m=>m.classList.add('hidden'))});
  }
  function initSearch() {
    $('omniInput').addEventListener('input',filterCards);
    $('omniInput').addEventListener('keydown',e=>{
      if(e.key==='Enter'&&e.target.value.trim()){
        const url=CFG.engines[window.NAV_HUB_ENGINE]+encodeURIComponent(e.target.value.trim());
        window.open(url,'_blank','noopener,noreferrer');
      }
    });
    $('clearBtn').addEventListener('click',()=>{$('omniInput').value='';filterCards();$('omniInput').focus()});
    window.addEventListener('keydown',e=>{
      const tag=document.activeElement?.tagName;
      if(e.key==='/'&&tag!=='INPUT'&&tag!=='TEXTAREA'&&!e.ctrlKey&&!e.metaKey){e.preventDefault();$('omniInput').focus()}
    });
  }
  function initScratchpad() {
    const drawer=$('scratchpadDrawer'),area=$('scratchText');
    const toggle=()=>drawer.classList.toggle('translate-x-full');
    $('openScratch').addEventListener('click',toggle);$('closeScratch').addEventListener('click',toggle);
    try{area.value=localStorage.getItem('claude_hub_scratch')||''}catch{}
    const count=()=>{$('scratchCount').textContent=`${area.value.length} 字元`};count();
    area.addEventListener('input',()=>{try{localStorage.setItem('claude_hub_scratch',area.value)}catch{}count()});
    $('copyScratch').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(area.value);$('copyScratch').textContent='已複製！';setTimeout(()=>{$('copyScratch').innerHTML='<i data-lucide="copy" class="w-3.5 h-3.5"></i> 複製全部';refreshIcons()},1500)}catch{alert('無法使用剪貼簿，請手動選取並複製。')}});
  }
  let timerRemaining=25*60,timerHandle=null,timerDeadline=null;
  function renderTimer(){const t=Math.max(0,timerRemaining);$('timerDisplay').textContent=`${String(Math.floor(t/60)).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`}
  function resetTimer(){clearInterval(timerHandle);timerHandle=null;timerRemaining=25*60;timerDeadline=null;$('timerBtn').textContent='開始';renderTimer()}
  function initTimer(){
    $('timerBtn').addEventListener('click',()=>{
      if(timerHandle){timerRemaining=Math.max(0,Math.ceil((timerDeadline-Date.now())/1000));clearInterval(timerHandle);timerHandle=null;$('timerBtn').textContent='繼續';renderTimer();return}
      if(timerRemaining<=0)timerRemaining=25*60;
      timerDeadline=Date.now()+timerRemaining*1000;
      $('timerBtn').textContent='暫停';
      const tick=()=>{
        timerRemaining=Math.max(0,Math.ceil((timerDeadline-Date.now())/1000));renderTimer();
        if(timerRemaining===0){clearInterval(timerHandle);timerHandle=null;$('timerBtn').textContent='開始';alert('專注時段完成！休息一下吧。')}
      };
      timerHandle=setInterval(tick,250);tick();
    });
    $('timerReset').addEventListener('click',resetTimer);
  }
  // Deliberately avoid eval() or Function() for calculator expressions.
  function safeMath(expression) {
    const s=expression.replace(/\s+/g,'');
    if(!s||s.length>200||/[^0-9.+\-*/()]/.test(s))throw Error('invalid');
    let p=0;
    function number(){const m=/^(?:\d+(?:\.\d*)?|\.\d+)/.exec(s.slice(p));if(!m)throw Error('number');p+=m[0].length;return Number(m[0])}
    function factor(){
      if(s[p]==='+'){p++;return factor()}
      if(s[p]==='-'){p++;return -factor()}
      if(s[p]==='('){p++;const v=expr();if(s[p++]!==')')throw Error('paren');return v}
      return number();
    }
    function term(){let v=factor();while(s[p]==='*'||s[p]==='/'){const op=s[p++];const b=factor();v=op==='*'?v*b:v/b;}return v}
    function expr(){let v=term();while(s[p]==='+'||s[p]==='-'){const op=s[p++],b=term();v=op==='+'?v+b:v-b}return v}
    const result=expr();if(p!==s.length||!Number.isFinite(result))throw Error('invalid');return result;
  }
  function initCalc(){
    const compute=()=>{try{$('calcResult').textContent=`結果: ${safeMath($('calcInput').value)}`}catch{$('calcResult').textContent='算式無效'}};
    $('calcBtn').addEventListener('click',compute);$('calcInput').addEventListener('keydown',e=>{if(e.key==='Enter')compute()});
  }
  let weatherData=null;
  function interpretWeather(code){
    if(code===0)return {icon:'sun',text:'晴朗'};
    if(code>=1&&code<=3)return {icon:'cloud-sun',text:'多雲'};
    if(code>=45&&code<=48)return {icon:'cloud-fog',text:'有霧'};
    if((code>=51&&code<=67)||(code>=80&&code<=82))return {icon:'cloud-rain',text:'有雨'};
    if(code>=95)return {icon:'cloud-lightning',text:'雷暴'};
    return {icon:'cloud',text:'陰天'};
  }
  async function fetchWeather(lat,lon,label){
    $('weatherModalLoc').textContent=label;
    try{
      const fields='temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,surface_pressure';
      const url=`https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&current=${fields}&daily=temperature_2m_max,temperature_2m_min,uv_index_max&timezone=auto`;
      const res=await fetch(url);if(!res.ok)throw Error(`Weather ${res.status}`);
      weatherData=await res.json();
      const info=interpretWeather(weatherData.current.weather_code);
      $('weatherTemp').textContent=`${Math.round(weatherData.current.temperature_2m)}°C`;
      $('weatherCondition').textContent=info.text;
      $('weatherIconContainer').replaceChildren(icon(info.icon,'w-3.5 h-3.5 text-amber-500'));
      refreshIcons();
    }catch(e){$('weatherCondition').textContent='天氣載入失敗'}
  }
  function refreshWeatherModal(){
    if(!weatherData)return;
    const c=weatherData.current,d=weatherData.daily;
    $('detailTemp').textContent=`${Math.round(c.temperature_2m)}°C`;
    $('detailDesc').textContent=interpretWeather(c.weather_code).text;
    $('detailApparent').textContent=`${Math.round(c.apparent_temperature)}°C`;
    $('detailHumidity').textContent=`${c.relative_humidity_2m}%`;
    $('detailWind').textContent=`${c.wind_speed_10m} km/h`;
    $('detailPressure').textContent=`${Math.round(c.surface_pressure)} hPa`;
    if(d?.temperature_2m_max?.length)$('detailRange').textContent=`最高 ${Math.round(d.temperature_2m_max[0])}° / 最低 ${Math.round(d.temperature_2m_min[0])}°`;
    if(d?.uv_index_max?.length)$('detailUv').textContent=`${d.uv_index_max[0]}`;
  }
  function initWeather(){
    const fallback=()=>fetchWeather(CFG.fallbackLocation.lat,CFG.fallbackLocation.lon,CFG.fallbackLocation.label);
    if(!('geolocation' in navigator)){fallback();return;}
    navigator.geolocation.getCurrentPosition(p=>{
      const {latitude,longitude}=p.coords;
      fetchWeather(latitude,longitude,`GPS: ${latitude.toFixed(2)}°N, ${longitude.toFixed(2)}°E`);
    },fallback,{timeout:8000});
  }
  document.addEventListener('DOMContentLoaded',()=>{
    renderNavigation();renderEngines();initTheme();bindModals();initSearch();initScratchpad();initTimer();initCalc();
    runAiTypewriter();updateClock();updateCountdown();setInterval(updateClock,1000);setInterval(updateCountdown,60000);initWeather();refreshIcons();
  });
})();
