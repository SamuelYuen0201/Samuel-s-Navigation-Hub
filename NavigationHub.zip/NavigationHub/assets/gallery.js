/* Immich shared-album slideshow with iframe fallback. */
(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  const refresh=()=>window.lucide?.createIcons();
  let assets=[],index=0,interval=null,playing=true,iframeMode=false;
  const conf=window.NAV_HUB_CONFIG.immich;
  const base=conf.baseUrl.replace(/\/$/,'');
  const key=conf.shareKey;
  const pageUrl=`${base}/share/${encodeURIComponent(key)}`;
  const thumb=(id,size='preview')=>`${base}/api/assets/${encodeURIComponent(id)}/thumbnail?size=${encodeURIComponent(size)}&key=${encodeURIComponent(key)}`;
  const orig=id=>`${base}/api/assets/${encodeURIComponent(id)}/original?key=${encodeURIComponent(key)}`;
  const video=id=>`${base}/api/assets/${encodeURIComponent(id)}/video/playback?key=${encodeURIComponent(key)}`;
  function shuffle(arr){const copy=[...arr];for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]]}return copy}
  function showAsset(next){
    if(!assets.length)return;
    index=(next+assets.length)%assets.length;
    const a=assets[index],img=$('immichMainImage'),vid=$('immichMainVideo'),ambient=$('immichAmbientBg'),url=thumb(a.id);
    $('immichStatusOverlay').classList.add('hidden');
    ambient.src=thumb(a.id,'thumbnail');ambient.classList.remove('hidden');
    if(a.type==='VIDEO'){
      img.classList.add('hidden');vid.poster=url;vid.src=video(a.id);vid.classList.remove('hidden');
      vid.onerror=()=>{vid.classList.add('hidden');img.src=url;img.classList.remove('hidden')};
      vid.play().catch(()=>{});
    }else{
      vid.pause();vid.removeAttribute('src');vid.load();vid.classList.add('hidden');
      img.classList.remove('hidden');img.style.opacity='.25';img.src=url;
      let fallback=0;
      img.onload=()=>{img.style.opacity='1'};
      img.onerror=()=>{if(++fallback===1)img.src=thumb(a.id,'thumbnail');else if(fallback===2)img.src=orig(a.id);else{img.classList.add('hidden');$('immichStatusOverlay').classList.remove('hidden');$('immichStatusTitle').textContent='相片無法載入，請使用「開啟相簿」'}};
    }
    const created=a.fileCreatedAt||a.localDateTime||a.createdAt;
    $('immichAssetDate').textContent=created?new Date(created).toLocaleDateString('zh-HK',{year:'numeric',month:'short',day:'numeric'}):(a.type==='VIDEO'?'🎬 旅行 B-Roll':'📷 旅行珍貴片段');
    const place=[a.exifInfo?.city,a.exifInfo?.country].filter(Boolean).join(', ');
    $('immichAssetLocationWrap').classList.toggle('hidden',!place);
    $('immichAssetLocation').textContent=place;
    $('immichAssetCounter').textContent=`${index+1} / ${assets.length}`;
    $('immichMetaOverlay').classList.remove('hidden');
    document.querySelectorAll('.immich-thumb-btn').forEach((b,i)=>{
      b.classList.toggle('border-claude-terracotta',i===index);
      b.classList.toggle('opacity-100',i===index);
      b.classList.toggle('border-transparent',i!==index);
      b.classList.toggle('opacity-60',i!==index);
    });
  }
  function thumbnails(){
    const strip=$('immichThumbStrip');strip.replaceChildren();
    if(assets.length<2)return;
    strip.classList.remove('hidden');
    assets.slice(0,24).forEach((a,i)=>{
      const b=document.createElement('button');b.type='button';b.className='immich-thumb-btn relative w-14 h-14 rounded-xl overflow-hidden border-2 border-transparent opacity-60 hover:opacity-100 transition-all shrink-0';
      const img=document.createElement('img');img.src=thumb(a.id,'thumbnail');img.alt=`第 ${i+1} 張縮圖`;img.loading='lazy';img.className='w-full h-full object-cover';
      b.append(img);b.addEventListener('click',()=>{showAsset(i);restartTimer()});strip.append(b);
    });
  }
  function updatePause(){
    const i=$('playPauseIcon');i.dataset.lucide=playing?'pause':'play';refresh();
  }
  function restartTimer(){
    clearInterval(interval);updatePause();
    if(!playing)return;
    interval=setInterval(()=>{if(!iframeMode&&assets.length)showAsset(index+1)},6500);
  }
  function switchMode(force){
    iframeMode=typeof force==='boolean'?force:!iframeMode;
    $('immichSlideshowStage').classList.toggle('hidden',iframeMode);
    $('immichIframeStage').classList.toggle('hidden',!iframeMode);
    $('immichThumbStrip').classList.toggle('hidden',iframeMode||assets.length<2);
    if(iframeMode&&$('immichShareIframe').getAttribute('src')==='about:blank')$('immichShareIframe').src=pageUrl;
    $('galleryModeText').textContent=iframeMode?'切換幻燈片模式':'內嵌相簿視窗';
  }
  async function init(){
    $('immichAlbumLink').href=pageUrl;
    $('btnPrevSlide').addEventListener('click',()=>{if(!iframeMode){showAsset(index-1);restartTimer()}});
    $('btnNextSlide').addEventListener('click',()=>{if(!iframeMode){showAsset(index+1);restartTimer()}});
    $('btnShuffleSlide').addEventListener('click',()=>{
      if(iframeMode&&assets.length===0){$('immichShareIframe').src=pageUrl;return}
      if(assets.length>1){let next=Math.floor(Math.random()*assets.length);if(next===index)next=(next+1)%assets.length;showAsset(next);restartTimer()}
    });
    $('btnPlayPauseSlide').addEventListener('click',()=>{playing=!playing;restartTimer()});
    $('btnSwitchGalleryMode').addEventListener('click',()=>switchMode());
    const endpoints=[`${base}/api/shared-links/me?key=${encodeURIComponent(key)}`,`${base}/api/shared-link/me?key=${encodeURIComponent(key)}`];
    let data=null;
    for(const endpoint of endpoints){
      try{const res=await fetch(endpoint,{mode:'cors',credentials:'omit'});if(res.ok){data=await res.json();break}}catch{}
    }
    if(data){
      const title=data.album?.albumName||data.description;
      if(title)$('immichAlbumBadge').textContent=title;
      let raw=Array.isArray(data.assets)?data.assets:(Array.isArray(data.album?.assets)?data.album.assets:[]);
      if(!raw.length&&data.album?.id){
        try{const res=await fetch(`${base}/api/albums/${encodeURIComponent(data.album.id)}?key=${encodeURIComponent(key)}`,{credentials:'omit'});if(res.ok){const obj=await res.json();raw=Array.isArray(obj.assets)?obj.assets:[]}}catch{}
      }
      if(raw.length){assets=shuffle(raw.filter(a=>a?.id));thumbnails();showAsset(0);restartTimer();return}
    }
    // Cross-origin API access often fails when Immich is hosted on another domain.
    switchMode(true);
  }
  document.addEventListener('DOMContentLoaded',init);
})();
