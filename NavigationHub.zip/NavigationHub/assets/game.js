/* 36-card, 3-to-match stacked tile game. */
(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  const CARD_W=46,CARD_H=56;
  const TYPES=[
    {id:'cam',icon:'camera',label:'影像',color:'text-amber-600 bg-amber-50 dark:bg-amber-950/40'},
    {id:'code',icon:'code-2',label:'開發',color:'text-blue-600 bg-blue-50 dark:bg-blue-950/40'},
    {id:'music',icon:'music',label:'音訊',color:'text-pink-600 bg-pink-50 dark:bg-pink-950/40'},
    {id:'coffee',icon:'coffee',label:'咖啡',color:'text-orange-700 bg-orange-50 dark:bg-orange-950/40'},
    {id:'lang',icon:'languages',label:'日語',color:'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40'},
    {id:'nas',icon:'server',label:'雲端',color:'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40'}
  ];
  let cards=[],dock=[],score=0,history=[],started=false;
  const audio=window.AudioContext||window.webkitAudioContext;let audioCtx=null;
  function tone(freq,kind='sine',duration=.12){
    try{
      if(!audio)return;
      if(!audioCtx)audioCtx=new audio();
      const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
      osc.type=kind;osc.frequency.setValueAtTime(freq,audioCtx.currentTime);
      gain.gain.setValueAtTime(.08,audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);
      osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+duration);
    }catch{}
  }
  function matchedSound(){tone(523.25,'triangle',.15);setTimeout(()=>tone(659.25,'triangle',.15),60);setTimeout(()=>tone(783.99,'triangle',.25),120)}
  function grid(rows,cols,x,y,stepX,stepY,layer){
    return Array.from({length:rows*cols},(_,i)=>({x:x+(i%cols)*stepX,y:y+Math.floor(i/cols)*stepY,layer}));
  }
  function initGame(){
    started=true;cards=[];dock=[];score=0;history=[];
    $('gameOverlay').classList.add('hidden');
    let pool=TYPES.flatMap(t=>Array.from({length:6},()=>t));
    for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]]}
    const positions=[
      ...grid(4,4,30,20,62,66,0),...grid(3,3,61,53,62,66,1),
      ...grid(2,3,92,53,62,66,2),
      {x:125,y:120,layer:3},{x:65,y:70,layer:3},{x:185,y:70,layer:3},
      {x:65,y:170,layer:3},{x:185,y:170,layer:3}
    ];
    cards=pool.map((type,i)=>({id:`card_${i}`,...type,...positions[i],status:'board'}));
    render();
  }
  function covered(card,active){
    return active.some(other=>other.id!==card.id&&other.layer>card.layer&&Math.abs(card.x-other.x)<CARD_W-6&&Math.abs(card.y-other.y)<CARD_H-8);
  }
  function render(){
    const board=$('gameBoard'),dockEl=$('gameDock');board.replaceChildren();dockEl.replaceChildren();
    const active=cards.filter(c=>c.status==='board');
    $('gameScore').textContent=score;$('gameRemaining').textContent=active.length;
    $('slotCount').textContent=`${dock.length} / 7`;
    for(const c of active){
      const blocked=covered(c,active);
      const div=document.createElement('div');
      div.className=`absolute rounded-xl border border-claude-border/80 dark:border-claude-darkBorder flex flex-col items-center justify-center select-none transition-all duration-150 ${c.color} ${blocked?'game-card-covered':'game-card-active'}`;
      div.style.cssText=`width:${CARD_W}px;height:${CARD_H}px;left:${c.x}px;top:${c.y}px;z-index:${c.layer*10}`;
      const i=document.createElement('i');i.dataset.lucide=c.icon;i.className='w-5 h-5 mb-0.5';
      const label=document.createElement('span');label.className='text-[9px] font-medium leading-none';label.textContent=c.label;
      div.append(i,label);
      if(!blocked){div.setAttribute('role','button');div.tabIndex=0;div.setAttribute('aria-label',`揀選${c.label}卡片`);div.addEventListener('click',()=>pick(c));div.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick(c)}})}
      board.append(div);
    }
    for(const c of dock){
      const div=document.createElement('div');div.className=`w-[42px] h-[52px] rounded-lg border border-claude-border dark:border-claude-darkBorder flex flex-col items-center justify-center ${c.color} shadow-sm shrink-0`;
      const i=document.createElement('i');i.dataset.lucide=c.icon;i.className='w-4 h-4 mb-0.5';
      const label=document.createElement('span');label.className='text-[8px] font-medium leading-none';label.textContent=c.label;
      div.append(i,label);dockEl.append(div);
    }
    window.lucide?.createIcons();
    if(active.length===0&&dock.length===0)endGame(true);
  }
  function snapshot(){return {statuses:cards.map(c=>c.status),score}}
  function pick(card){
    const active=cards.filter(c=>c.status==='board');
    if(card.status!=='board'||covered(card,active)||dock.length>=7||!$('gameOverlay').classList.contains('hidden'))return;
    history.push(snapshot());
    card.status='dock';dock.push(card);dock.sort((a,b)=>a.type.localeCompare(b.type));
    tone(440,'sine',.08);
    const counts={};for(const c of dock)counts[c.type]=(counts[c.type]||0)+1;
    const type=Object.keys(counts).find(k=>counts[k]>=3);
    if(type){
      let removed=0;dock=dock.filter(c=>{if(c.type===type&&removed<3){c.status='cleared';removed++;return false}return true});
      score+=100;matchedSound();
    }
    render();
    if(dock.length>=7)endGame(false);
  }
  function undo(){
    if(!history.length)return;
    const state=history.pop();
    cards.forEach((c,i)=>c.status=state.statuses[i]);
    dock=cards.filter(c=>c.status==='dock').sort((a,b)=>a.type.localeCompare(b.type));
    score=state.score;$('gameOverlay').classList.add('hidden');render();
  }
  function endGame(win){
    const overlay=$('gameOverlay');overlay.classList.remove('hidden');
    $('gameOverlayTitle').textContent=win?'通關大吉！🎉':'槽位已滿 😅';
    $('gameOverlayMsg').textContent=win?`太強了！完美消除所有卡片，總分: ${score}`:'暫存槽已達 7 張上限，重開一局再接再厲！';
    const ico=document.createElement('i');ico.dataset.lucide=win?'trophy':'alert-circle';ico.className=`w-6 h-6 ${win?'text-amber-500':'text-rose-500'}`;
    $('gameOverlayIcon').replaceChildren(ico);window.lucide?.createIcons();
    if(win){tone(523,'sine',.2);setTimeout(()=>tone(659,'sine',.3),100)}else tone(220,'sawtooth',.3);
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('openGame').addEventListener('click',()=>{$('gameModal').classList.remove('hidden');if(!started)initGame()});
    $('btnUndo').addEventListener('click',undo);
    $('btnRestart').addEventListener('click',initGame);
    $('btnRestartOverlay').addEventListener('click',initGame);
  });
})();
