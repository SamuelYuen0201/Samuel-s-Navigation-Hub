/* NavigationHub site configuration. This is a structured rewrite of the pasted single-page layout. */
window.NAV_HUB_CONFIG = {
  title: 'Samuel\'s Hub',
  examDate: '2027-04-08T08:30:00+08:00',
  fallbackLocation: { lat: 22.3193, lon: 114.1694, label: '香港中心坐標 (預設)' },
  immich: {
    baseUrl: 'https://photo.samuelyuen.com',
    shareKey: 'Ac7L4VgHBhpl5f0wbtm4xt7kiqzvjPAggAS4geDpaFuO3oJ1zOhzbUzkQn30vPI9NGE'
  },
  engines: {
    Google: 'https://www.google.com/search?q=',
    DuckDuckGo: 'https://duckduckgo.com/?q=',
    GitHub: 'https://github.com/search?q=',
    Scholar: 'https://scholar.google.com/scholar?q='
  },
  sections: [
    {
      title: '社交與創作', english: 'Social & Media', icon:'share-2',
      subtitle:'視覺作品、影音與代碼倉庫', columns:'md:grid-cols-4',
      links: [
        { title:'Instagram', subtitle:'@y.pakh', url:'https://www.instagram.com/y.pakh', footer:'Photo & Stories', badge:'● IG', icon:'instagram', color:'pink' },
        { title:'YouTube', subtitle:'@ypakh', url:'https://youtube.com/@ypakh', footer:'Channel & Vlogs', badge:'● Video', icon:'youtube', color:'red' },
        { title:'GitHub', subtitle:'SamuelYuen0201', url:'https://github.com/SamuelYuen0201', footer:'Code Repositories', badge:'● Dev', icon:'github', color:'zinc' },
        { title:'Spotify', subtitle:'Music Profile', url:'https://open.spotify.com/user/31fm5nzg362ywkafyhyqrghz3bzq', footer:'Playlists & Tracks', badge:'● Audio', icon:'music-2', color:'green' }
      ]
    },
    {
      title:'儲存與管理', english:'Storage & Infrastructure', icon:'server',
      subtitle:'Synology NAS 主機與媒體服務', columns:'md:grid-cols-4',
      links:[
        { title:'Synology DSM', subtitle:'nas.samuelyuen.com', url:'https://nas.samuelyuen.com', footer:'DSM 控制台', badge:'● 5001', icon:'hard-drive', color:'orange' },
        { title:'Immich 相片庫', subtitle:'photo.samuelyuen.com', url:'https://photo.samuelyuen.com', footer:'Photo Cloud', badge:'● 2283', icon:'camera', color:'amber' },
        { title:'Emby 影音媒體庫', subtitle:'emby.samuelyuen.com', url:'https://emby.samuelyuen.com', footer:'Media Server', badge:'● 8096', icon:'tv', color:'fuchsia' },
        { title:'Browse 檔案穿透', subtitle:'browse.samuelyuen.com', url:'https://browse.samuelyuen.com', footer:'File Browser', badge:'● LAN Proxy', icon:'folder-search', color:'blue' }
      ]
    },
    {
      title:'筆記、學習與日程', english:'Notes, Study & Schedule', icon:'book-open',
      subtitle:'日常靈感、檢定題庫與行事曆', columns:'md:grid-cols-3 lg:grid-cols-5',
      links:[
        { title:'Memos (Primary)', subtitle:'memos.yph.app', url:'https://memos.yph.app', footer:'碎片筆記平台', badge:'● 5230', icon:'message-square-quote', color:'teal' },
        { title:'Memos (Mirror)', subtitle:'memos.samuelyuen.com', url:'https://memos.samuelyuen.com', footer:'備用筆記節點', badge:'● 5230', icon:'sticky-note', color:'teal' },
        { title:'JLPT 日本語學習庫', subtitle:'jlpt.samuelyuen.com', url:'https://jlpt.samuelyuen.com', footer:'N2 · N3 練習題庫', badge:'● 8321', icon:'languages', color:'indigo' },
        { title:'CalcX 科學計算器', subtitle:'calcx-public-beta.netlify.app', url:'https://calcx-public-beta.netlify.app/', footer:'DSE 數學 · fx-50FH II', badge:'● Beta', icon:'calculator', color:'violet' },
        { title:'Google Calendar', subtitle:'calendar.google.com', url:'https://calendar.google.com', footer:'溫習與行事曆', badge:'● Schedule', icon:'calendar-days', color:'blue' }
      ]
    },
    {
      title:'個人主頁與探索發布', english:'Identity, Sites & Maps', icon:'globe',
      subtitle:'前端發布、個人品牌與私房散步推薦', columns:'md:grid-cols-3',
      links:[
        { title:'Samuel Yuen 個人主站', subtitle:'samuelyuen.com', url:'https://samuelyuen.com', footer:'Main Portfolio', badge:'● 4321', icon:'user', color:'stone' },
        { title:'YPH.APP 短鏈入口', subtitle:'yph.app', url:'https://yph.app', footer:'Short Link & Redir', badge:'● 4321', icon:'link', color:'emerald' },
        { title:'香港嘅隱世秘境 ><!🫧✨', subtitle:'Samuel Yuen · 私房散步清單', url:'https://www.google.com/maps/placelists/list/wuVDURkR-kQWhsMMaLCWmHU3Sd0hHg?source=sh%2Fx%2Fuk%2Fm0%2F0&kgs=f9919117eb146101', footer:'Google Maps 私房清單', badge:'● Maps', icon:'map-pin', color:'cyan' }
      ]
    }
  ]
};
