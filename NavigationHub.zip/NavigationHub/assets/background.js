/* Interactive topographic contours + magnetic spring dot field. */
(() => {
  'use strict';
  const canvas=document.getElementById('liveFluidCanvas');
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  if(!ctx)return;
  const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
  let width=0,height=0,dpr=1,dotGrid=[],topoCols=0,topoRows=0,cell=32,field=new Float32Array(),t=0;
  const pulses=[];
  const ptr={x:-9999,y:-9999,vx:0,vy:0,lastX:-9999,lastY:-9999,active:false};
  const perm=new Uint8Array(512);
  (()=>{
    const p=Uint8Array.from({length:256},(_,i)=>i);let seed=20260408;
    for(let i=255;i>0;i--){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const j=seed%(i+1);[p[i],p[j]]=[p[j],p[i]]}
    for(let i=0;i<512;i++)perm[i]=p[i&255];
  })();
  const fade=x=>x*x*x*(x*(x*6-15)+10);
  const lerp=(a,b,t)=>a+t*(b-a);
  function grad2(hash,x,y){const h=hash&7,u=h<4?x:y,v=h<4?y:x;return ((h&1)?-u:u)+((h&2)?-2*v:2*v)}
  function perlin2D(x,y){
    const X=Math.floor(x)&255,Y=Math.floor(y)&255;
    x-=Math.floor(x);y-=Math.floor(y);
    const u=fade(x),v=fade(y),A=perm[X]+Y,B=perm[X+1]+Y;
    return lerp(lerp(grad2(perm[A],x,y),grad2(perm[B],x-1,y),u),lerp(grad2(perm[A+1],x,y-1),grad2(perm[B+1],x-1,y-1),u),v)*.5+.5;
  }
  function elevation(x,y,time){
    const a=perlin2D(x*.0019+time*.14,y*.0019-time*.1);
    const b=perlin2D(x*.0044-time*.09+41.7,y*.0044+time*.12+19.3);
    return a*.72+b*.28;
  }
  function resize(){
    width=innerWidth;height=innerHeight;dpr=Math.min(devicePixelRatio||1,2);
    canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    dotGrid=[];
    const spacing=width<640?34:30,cols=Math.ceil(width/spacing)+1,rows=Math.ceil(height/spacing)+1;
    const ox=(width-(cols-1)*spacing)/2,oy=(height-(rows-1)*spacing)/2;
    for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
      const x=ox+c*spacing,y=oy+r*spacing;
      dotGrid.push({ox:x,oy:y,x,y,vx:0,vy:0,energy:0});
    }
    cell=width<640?38:32;topoCols=Math.ceil(width/cell)+1;topoRows=Math.ceil(height/cell)+1;
    field=new Float32Array(topoCols*topoRows);
  }
  function updatePointer(x,y){
    ptr.vx=x-(ptr.lastX===-9999?x:ptr.lastX);ptr.vy=y-(ptr.lastY===-9999?y:ptr.lastY);
    ptr.x=ptr.lastX=x;ptr.y=ptr.lastY=y;ptr.active=true;
  }
  function pulse(x,y,max=260,strength=1){
    pulses.push({x,y,radius:6,max,speed:4.8,strength});if(pulses.length>8)pulses.shift();
  }
  window.addEventListener('resize',resize);
  window.addEventListener('mousemove',e=>updatePointer(e.clientX,e.clientY),{passive:true});
  window.addEventListener('touchmove',e=>{if(e.touches?.[0])updatePointer(e.touches[0].clientX,e.touches[0].clientY)},{passive:true});
  window.addEventListener('mousedown',e=>pulse(e.clientX,e.clientY,270,1.35),{passive:true});
  window.addEventListener('touchstart',e=>{if(e.touches?.[0]){updatePointer(e.touches[0].clientX,e.touches[0].clientY);pulse(e.touches[0].clientX,e.touches[0].clientY,240,1.2)}},{passive:true});
  window.addEventListener('mouseleave',()=>{ptr.active=false;ptr.x=ptr.y=-9999});
  const interpolate=(x1,y1,v1,x2,y2,v2,level)=>{
    const delta=v2-v1,ratio=Math.abs(delta)<1e-5?.5:(level-v1)/delta;
    return [x1+ratio*(x2-x1),y1+ratio*(y2-y1)];
  };
  function trace(level){
    ctx.beginPath();
    const segment=(a,b)=>{ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])};
    for(let r=0;r<topoRows-1;r++){
      const y0=r*cell,y1=(r+1)*cell,row=r*topoCols,next=(r+1)*topoCols;
      for(let c=0;c<topoCols-1;c++){
        const x0=c*cell,x1=(c+1)*cell;
        const tl=field[row+c],tr=field[row+c+1],br=field[next+c+1],bl=field[next+c];
        const a=+(tl>=level),b=+(tr>=level),cc=+(br>=level),d=+(bl>=level);
        const mask=a*8+b*4+cc*2+d;
        if(mask===0||mask===15)continue;
        // Compare individual corner states (not bitwise masks) to determine crossing edges.
        const top=a!==b?interpolate(x0,y0,tl,x1,y0,tr,level):null;
        const right=b!==cc?interpolate(x1,y0,tr,x1,y1,br,level):null;
        const bottom=cc!==d?interpolate(x1,y1,br,x0,y1,bl,level):null;
        const left=d!==a?interpolate(x0,y1,bl,x0,y0,tl,level):null;
        switch(mask){
          case 1:case 14:segment(left,bottom);break;
          case 2:case 13:segment(bottom,right);break;
          case 3:case 12:segment(left,right);break;
          case 4:case 11:segment(top,right);break;
          case 5:segment(left,top);segment(bottom,right);break;
          case 6:case 9:segment(top,bottom);break;
          case 7:case 8:segment(left,top);break;
          case 10:segment(left,bottom);segment(top,right);break;
        }
      }
    }
    ctx.stroke();
  }
  const levels=[{v:.28,m:false},{v:.35,m:true},{v:.42,m:false},{v:.49,m:false},{v:.56,m:true},{v:.63,m:false},{v:.70,m:true}];
  let frameCounter=0;
  function render(){
    const dark=document.documentElement.classList.contains('dark');
    ctx.clearRect(0,0,width,height);
    t+=reducedMotion.matches?0:.0085;
    if(ptr.active){
      const grad=ctx.createRadialGradient(ptr.x,ptr.y,0,ptr.x,ptr.y,320);
      grad.addColorStop(0,dark?'rgba(217,119,87,.11)':'rgba(217,119,87,.09)');
      grad.addColorStop(.5,'rgba(230,161,92,.04)');grad.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=grad;ctx.beginPath();ctx.arc(ptr.x,ptr.y,320,0,Math.PI*2);ctx.fill();
    }
    for(let r=0;r<topoRows;r++)for(let c=0;c<topoCols;c++){
      const x=c*cell,y=r*cell,idx=r*topoCols+c;let h=elevation(x,y,t);
      if(ptr.active){const dx=x-ptr.x,dy=y-ptr.y,d2=dx*dx+dy*dy;if(d2<55000)h+=Math.exp(-d2/18000)*.085}
      field[idx]=h;
    }
    ctx.lineCap='round';ctx.lineJoin='round';
    for(const l of levels){
      ctx.strokeStyle=l.m?(dark?'rgba(217,119,87,.17)':'rgba(217,119,87,.16)'):(dark?'rgba(237,235,232,.055)':'rgba(122,117,109,.075)');
      ctx.lineWidth=l.m?1.15:.75;trace(l.v);
    }
    for(let i=pulses.length-1;i>=0;i--){
      const p=pulses[i];p.radius+=p.speed;const progress=p.radius/p.max;
      if(progress>=1){pulses.splice(i,1);continue}
      ctx.beginPath();ctx.arc(p.x,p.y,p.radius,0,Math.PI*2);
      ctx.strokeStyle=`rgba(217,119,87,${(1-progress)*(dark?.28:.22)})`;
      ctx.lineWidth=1.1*(1-progress*.5);ctx.stroke();
    }
    for(const d of dotGrid){
      const local=elevation(d.ox,d.oy,t),angle=local*Math.PI*4;
      const targetX=d.ox+Math.cos(angle)*1.6,targetY=d.oy+Math.sin(angle)*1.6;
      let energy=0;
      if(ptr.active){
        const dx=d.x-ptr.x,dy=d.y-ptr.y,dist=Math.hypot(dx,dy);
        if(dist<165&&dist>.01){
          const f=(1-dist/165)**1.8,radX=dx/dist,radY=dy/dist;
          d.vx+=radX*f*2.65-radY*f*.45+ptr.vx*f*.03;
          d.vy+=radY*f*2.65+radX*f*.45+ptr.vy*f*.03;energy=Math.max(energy,f);
        }
      }
      for(const p of pulses){
        const dx=d.x-p.x,dy=d.y-p.y,dist=Math.hypot(dx,dy),bandDist=Math.abs(dist-p.radius);
        if(bandDist<32&&dist>.01){const f=(1-bandDist/32)*(1-p.radius/p.max)*p.strength;d.vx+=dx/dist*f*2.2;d.vy+=dy/dist*f*2.2;energy=Math.max(energy,f)}
      }
      d.vx=(d.vx+(targetX-d.x)*.075)*.82;d.vy=(d.vy+(targetY-d.y)*.075)*.82;
      d.x+=d.vx;d.y+=d.vy;
      const displacement=Math.hypot(d.x-targetX,d.y-targetY);
      d.energy+=(Math.min(1,energy+displacement*.045)-d.energy)*.18;
      const near=(Math.abs(local-.35)<.018||Math.abs(local-.56)<.018)?.25:0;
      const highlight=Math.min(1,d.energy+near);
      if(displacement>1.25){
        const theta=Math.atan2(d.y-d.oy,d.x-d.ox),length=Math.min(7.5,1.5+displacement*.38);
        const dx=Math.cos(theta)*length,dy=Math.sin(theta)*length;
        ctx.beginPath();ctx.moveTo(d.x-dx*.6,d.y-dy*.6);ctx.lineTo(d.x+dx,d.y+dy);
        ctx.strokeStyle=`rgba(217,119,87,${.28+highlight*.58})`;ctx.lineWidth=1.45;ctx.stroke();
      }else{
        ctx.beginPath();ctx.arc(d.x,d.y,1.05+highlight*.85,0,Math.PI*2);
        ctx.fillStyle=highlight>.12?`rgba(217,119,87,${.22+highlight*.55})`:(dark?'rgba(237,235,232,.14)':'rgba(122,117,109,.18)');ctx.fill();
      }
    }
    if(!reducedMotion.matches)requestAnimationFrame(render);
    frameCounter++;
  }
  resize();render();
  reducedMotion.addEventListener?.('change',()=>{if(!reducedMotion.matches)render()});
})();
