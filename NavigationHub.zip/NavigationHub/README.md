# NavigationHub

**Samuel's Hub — Personal Navigation Dashboard**

This is a **working refactor derived from the HTML supplied in the conversation**, not a byte-for-byte archive of that original HTML. It keeps the original visual direction, navigation links, interactive background, search, weather, DSE countdown, notes, timer, calculator, card game and Immich gallery. The files are organized so further maintenance is easier.

## Quick start

No build system is required. To serve the files locally (recommended rather than `file://`):

```bash
cd NavigationHub
python3 -m http.server 8080
```

Then open <http://localhost:8080>.

The CSS and icon/font libraries load from CDNs; internet access is needed for the full appearance.

## Project layout

```text
NavigationHub/
├── index.html
├── assets/
│   ├── app.js          # Navigation, search, timer, notes, weather, theme
│   ├── background.js   # Perlin contours and magnetic spring dots
│   ├── config.js       # All nav cards, services and exam date
│   ├── gallery.js      # Immich slideshow and iframe fallback
│   ├── game.js         # Card-matching game
│   └── style.css       # Glass UI / animations / reusable styles
├── .gitignore
└── README.md
```

## Publishing on GitHub

1. Create a **private** repository called `NavigationHub` under `SamuelYuen0201`.
2. Upload `index.html`, `assets/`, `.gitignore` and `README.md` into the repository root (do not upload only the ZIP file).
3. If the site should be public, review privacy and internal-service exposure first. GitHub Pages is not available for all private-repository combinations, and publishing the website is distinct from keeping its source private.
4. Alternatively use Netlify for this static site, or place the files behind your preferred reverse proxy on the NAS.

## Important implementation notes

- **Changed from original:** The automatic fingerprint/device UUID/WebRTC IP tracking and `POST /api/telemetry` have been *omitted* from the refactor for privacy. If server telemetry is needed, add it separately with a proportionate consent, retention and security design. The privacy text was updated accordingly. This is not an exact source snapshot.
- **Calculator:** Replaced runtime `Function(...)` evaluation with a restricted arithmetic parser.
- **Marching squares:** Fixed crossing-edge detection used in topographic contours.
- **Game:** Undo restores the prior game snapshot, including moves that triggered elimination.
- **Weather:** Requires geolocation permission for local weather and uses the Open-Meteo API. Default fallback location is Hong Kong.
- **Immich:** The shared-link API is accessed across domains and depends on the Immich version and CORS settings. If fetching fails, the gallery tries the original share iframe. Some Immich deployments disallow embedding with `X-Frame-Options` / CSP. The Open Album link remains available regardless.
- **Security:** The share key embedded in `assets/config.js` is equivalent to a public share link, so anyone who can view the code can copy it. Do not place private API keys or NAS credentials in static client-side code. Listing NAS hostnames and ports publicly may disclose infrastructure details.
- **DSE exam:** This package retains the supplied `2027-04-08T08:30:00+08:00` date; confirm it against the official published timetable before relying on it.
- **Animations:** A reduced-motion setting turns off the continuous animation.
- **Dependencies:** Tailwind browser CDN and the `@latest` icon package are fine for prototyping but should be pinned / built for production.

## License

No open-source license is granted by default. © Samuel Yuen.
